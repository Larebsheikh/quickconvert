import 'package:flutter/material.dart';

enum CategoryType { linear, temperature }

/// One convertible category (Length, Mass, Temperature, ...).
///
/// - `linear` categories store each unit's factor relative to a shared
///   base unit (e.g. meters for Length), so converting is just
///   `value * fromFactor / toFactor`.
/// - `temperature` is handled with its own formulas since Celsius/
///   Fahrenheit/Kelvin aren't related by a simple multiplier.
class ConversionCategory {
  final String name;
  final IconData icon;
  final CategoryType type;
  final Map<String, double> unitsToBase;
  final String baseUnitLabel;

  const ConversionCategory({
    required this.name,
    required this.icon,
    required this.type,
    this.unitsToBase = const {},
    this.baseUnitLabel = '',
  });

  List<String> get unitNames => type == CategoryType.temperature
      ? const ['Celsius', 'Fahrenheit', 'Kelvin']
      : unitsToBase.keys.toList();

  double convert(double value, String from, String to) {
    if (type == CategoryType.temperature) {
      return _convertTemperature(value, from, to);
    }
    final fromFactor = unitsToBase[from];
    final toFactor = unitsToBase[to];
    if (fromFactor == null || toFactor == null) return double.nan;
    final base = value * fromFactor;
    return base / toFactor;
  }

  double _convertTemperature(double value, String from, String to) {
    double celsius;
    switch (from) {
      case 'Fahrenheit':
        celsius = (value - 32) * 5 / 9;
        break;
      case 'Kelvin':
        celsius = value - 273.15;
        break;
      default:
        celsius = value;
    }
    switch (to) {
      case 'Fahrenheit':
        return celsius * 9 / 5 + 32;
      case 'Kelvin':
        return celsius + 273.15;
      default:
        return celsius;
    }
  }
}
