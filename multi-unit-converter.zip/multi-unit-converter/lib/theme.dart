import 'package:flutter/material.dart';

/// Palette idea: a technical instrument panel — near-black background,
/// a mint/teal accent for the "active" reading (like a digital caliper
/// display), violet as a secondary accent for category selection.
class AppColors {
  static const bg = Color(0xFF0F1115);
  static const panel = Color(0xFF171A20);
  static const panelLine = Color(0xFF262B33);
  static const text = Color(0xFFECEDEE);
  static const muted = Color(0xFF8A8F98);
  static const accent = Color(0xFF5EEAD4); // mint/teal — the reading
  static const accent2 = Color(0xFFC4B5FD); // violet — category selection
}

ThemeData buildAppTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: AppColors.bg,
    colorScheme: base.colorScheme.copyWith(
      primary: AppColors.accent,
      secondary: AppColors.accent2,
      surface: AppColors.panel,
    ),
    textTheme: base.textTheme.apply(
      bodyColor: AppColors.text,
      displayColor: AppColors.text,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.bg,
      foregroundColor: AppColors.text,
      elevation: 0,
      centerTitle: false,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.panel,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.panelLine),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.panelLine),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.accent, width: 1.5),
      ),
    ),
    cardTheme: CardThemeData(
      color: AppColors.panel,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: const BorderSide(color: AppColors.panelLine),
      ),
    ),
    chipTheme: base.chipTheme.copyWith(
      backgroundColor: AppColors.panel,
      selectedColor: AppColors.accent2.withOpacity(0.18),
      side: const BorderSide(color: AppColors.panelLine),
      labelStyle: const TextStyle(color: AppColors.text, fontSize: 13),
      secondaryLabelStyle: const TextStyle(color: AppColors.accent2, fontSize: 13),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
    ),
  );
}
