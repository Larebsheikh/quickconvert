import 'package:flutter/material.dart';
import '../models/conversion_category.dart';

/// All conversion factors are relative to a base unit per category
/// (documented in `baseUnitLabel`). Values are standard, widely-published
/// conversion constants.
final List<ConversionCategory> conversionCategories = [
  const ConversionCategory(
    name: 'Length',
    icon: Icons.straighten,
    type: CategoryType.linear,
    baseUnitLabel: 'meters',
    unitsToBase: {
      'Millimeters': 0.001,
      'Centimeters': 0.01,
      'Meters': 1,
      'Kilometers': 1000,
      'Inches': 0.0254,
      'Feet': 0.3048,
      'Yards': 0.9144,
      'Miles': 1609.344,
    },
  ),
  const ConversionCategory(
    name: 'Mass',
    icon: Icons.scale,
    type: CategoryType.linear,
    baseUnitLabel: 'kilograms',
    unitsToBase: {
      'Milligrams': 0.000001,
      'Grams': 0.001,
      'Kilograms': 1,
      'Metric Tons': 1000,
      'Ounces': 0.0283495,
      'Pounds': 0.453592,
      'Stone': 6.35029,
    },
  ),
  const ConversionCategory(
    name: 'Temperature',
    icon: Icons.thermostat,
    type: CategoryType.temperature,
  ),
  const ConversionCategory(
    name: 'Volume',
    icon: Icons.science,
    type: CategoryType.linear,
    baseUnitLabel: 'liters',
    unitsToBase: {
      'Milliliters': 0.001,
      'Liters': 1,
      'Cubic Meters': 1000,
      'Teaspoons': 0.00492892,
      'Tablespoons': 0.0147868,
      'Cups': 0.24,
      'Fluid Ounces': 0.0295735,
      'Pints': 0.473176,
      'Quarts': 0.946353,
      'Gallons': 3.78541,
    },
  ),
  const ConversionCategory(
    name: 'Area',
    icon: Icons.crop_square,
    type: CategoryType.linear,
    baseUnitLabel: 'square meters',
    unitsToBase: {
      'Square Millimeters': 0.000001,
      'Square Centimeters': 0.0001,
      'Square Meters': 1,
      'Square Kilometers': 1000000,
      'Square Feet': 0.092903,
      'Square Yards': 0.836127,
      'Acres': 4046.86,
      'Hectares': 10000,
    },
  ),
  const ConversionCategory(
    name: 'Time',
    icon: Icons.timer,
    type: CategoryType.linear,
    baseUnitLabel: 'seconds',
    unitsToBase: {
      'Milliseconds': 0.001,
      'Seconds': 1,
      'Minutes': 60,
      'Hours': 3600,
      'Days': 86400,
      'Weeks': 604800,
    },
  ),
  const ConversionCategory(
    name: 'Speed',
    icon: Icons.speed,
    type: CategoryType.linear,
    baseUnitLabel: 'meters/second',
    unitsToBase: {
      'Meters/second': 1,
      'Kilometers/hour': 0.277778,
      'Miles/hour': 0.44704,
      'Knots': 0.514444,
      'Feet/second': 0.3048,
    },
  ),
  const ConversionCategory(
    name: 'Digital Storage',
    icon: Icons.storage,
    type: CategoryType.linear,
    baseUnitLabel: 'bytes',
    unitsToBase: {
      'Bits': 0.125,
      'Bytes': 1,
      'Kilobytes': 1024,
      'Megabytes': 1048576,
      'Gigabytes': 1073741824,
      'Terabytes': 1099511627776,
    },
  ),
];
