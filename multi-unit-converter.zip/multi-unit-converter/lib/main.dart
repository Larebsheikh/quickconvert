import 'package:flutter/material.dart';
import 'screens/converter_screen.dart';
import 'theme.dart';

void main() {
  runApp(const MultiUnitConverterApp());
}

class MultiUnitConverterApp extends StatelessWidget {
  const MultiUnitConverterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Multi-Unit Converter',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      home: const ConverterScreen(),
    );
  }
}
