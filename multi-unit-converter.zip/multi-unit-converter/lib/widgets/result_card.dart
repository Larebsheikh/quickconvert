import 'package:flutter/material.dart';
import '../theme.dart';

class ResultCard extends StatelessWidget {
  final String resultText;
  final String toUnit;
  final String? rateLine;
  final bool hasError;

  const ResultCard({
    super.key,
    required this.resultText,
    required this.toUnit,
    this.rateLine,
    this.hasError = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: AppColors.panel,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.panelLine),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'RESULT',
            style: TextStyle(fontSize: 11, letterSpacing: 0.8, color: AppColors.muted),
          ),
          const SizedBox(height: 10),
          Row(
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: [
              Flexible(
                child: Text(
                  resultText,
                  style: TextStyle(
                    fontSize: 34,
                    fontWeight: FontWeight.w700,
                    color: hasError ? AppColors.muted : AppColors.accent,
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const SizedBox(width: 8),
              Text(toUnit, style: const TextStyle(fontSize: 15, color: AppColors.muted)),
            ],
          ),
          if (rateLine != null) ...[
            const SizedBox(height: 12),
            Text(rateLine!, style: const TextStyle(fontSize: 12.5, color: AppColors.muted)),
          ],
        ],
      ),
    );
  }
}
