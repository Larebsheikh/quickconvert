import 'package:flutter/material.dart';
import '../data/unit_data.dart';
import '../theme.dart';

class CategoryChipBar extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onSelected;

  const CategoryChipBar({super.key, required this.selectedIndex, required this.onSelected});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: conversionCategories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final category = conversionCategories[index];
          final selected = index == selectedIndex;
          return ChoiceChip(
            selected: selected,
            onSelected: (_) => onSelected(index),
            avatar: Icon(
              category.icon,
              size: 16,
              color: selected ? AppColors.accent2 : AppColors.muted,
            ),
            label: Text(category.name),
          );
        },
      ),
    );
  }
}
